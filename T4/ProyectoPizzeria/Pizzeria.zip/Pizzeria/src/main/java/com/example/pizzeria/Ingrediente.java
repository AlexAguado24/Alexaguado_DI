package com.example.pizzeria;

public class Ingrediente {

    private String nombre;

    public Ingrediente(String nombre) {
        this.nombre = nombre;
    }

    public void mostrarDatos(){
        System.out.println("Ingrediente: "+nombre);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return  nombre;
    }
}
